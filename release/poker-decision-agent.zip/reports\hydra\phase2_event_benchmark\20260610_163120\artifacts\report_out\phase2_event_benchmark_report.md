# Phase 2 Event-Normalization Baseline Benchmark

## Objective

Compare deterministic parsing, zero-shot extraction, few-shot extraction, and candidate ranking on the same grouped OCR/dealer-log evaluation split.

## Dataset

- Dataset: `evaluation\event_extraction_phase1.jsonl`
- Split: `test`
- Examples: `25`
- Backend: `heuristic`
- Models: `heuristic_text`

## Results

| method | model | accuracy | macro_f1 | precision_macro | recall_macro | schema_validity_rate | event_type_exact_match | action_exact_match | amount_exact_match | average_latency_ms | peak_memory_mb | unmatched_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| deterministic_parser | - | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 19.4793 | 0.0679 | 0.0000 |
| few_shot_5 | heuristic_text | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 18.5714 | 0.0504 | 0.0000 |
| few_shot_10 | heuristic_text | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 18.7221 | 0.0525 | 0.0000 |
| candidate_ranker | heuristic_text | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 20.6678 | 0.0974 | 0.0000 |
| zero_shot | heuristic_text | 0.9600 | 0.7414 | 0.7500 | 0.7333 | 1.0000 | 0.9600 | 0.9333 | 1.0000 | 18.1145 | 0.0498 | 0.0400 |

## Best System

`deterministic_parser` with model `-` reached macro F1 `1.0000` and exact-event accuracy `1.0000`.

## Notes

The default backend is deterministic and intended for reproducible local delivery checks. Use `--backend transformers` with the configured model IDs to run the same benchmark against Qwen or SmolLM models when the model weights are available locally or can be downloaded.
