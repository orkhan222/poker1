# Delivery Report

## Executive Status

- Repository audit: `PASS`
- Repository hygiene: `PASS`
- Delivery verification: `PASS`
- Production decision gate: `FAIL`

The repository is packaged for technical handoff with reproducible experiments, model artifacts, service code, evaluation reports, and delivery checks. The current model remains research-stage for decision-policy use because dataset blockers are still present.

## Modified Files

- `poker_agent/features.py`, `poker_agent/model.py`, `poker_agent/service.py`, `poker_agent/slices.py`, `poker_agent/validation.py`
- `poker_agent/event_schema.py`, `poker_agent/event_normalization/`, `poker_agent/llm_decision.py`, `poker_agent/schemas.py`
- `scripts/train_policy.py`, `scripts/train_policy_bundle.py`, `scripts/evaluate_policy.py`, `scripts/research_experiment.py`
- `scripts/build_event_schema_dataset.py`, `scripts/benchmark.py`, `scripts/evaluate_llm_decision_agent.py`
- `scripts/audit_repository.py`, `scripts/check_repo_hygiene.py`, `scripts/production_gate.py`, `scripts/verify_delivery.py`
- `Dockerfile`, `docker-compose.yml`, `install.ps1`, `run_server.ps1`, `train_and_evaluate.ps1`, `complete_delivery.ps1`
- `README.md`, `requirements.txt`, `.gitignore`, `.dockerignore`

## New Files And Directories

- `configs/` Hydra configuration hierarchy
- `docs/llm_agent_architecture.md`
- `evaluation.ipynb`
- `evaluation/event_extraction_gold.jsonl`
- `evaluation/event_schema_v1.json`, `evaluation/event_extraction_phase1.jsonl`, `evaluation/event_extraction_phase1_splits.json`
- `scripts/run_hydra_experiment.py`
- `scripts/benchmark.py`
- `scripts/llm_event_extraction.py`, `scripts/llm_event_benchmark.py`, `scripts/llm_event_gold_eval.py`, `scripts/llm_transformer_gold_eval.py`
- `scripts/evaluate_llm_decision_agent.py`
- `scripts/audit_repository.py`, `scripts/check_repo_hygiene.py`, `scripts/production_gate.py`, `scripts/verify_delivery.py`
- `complete_delivery.ps1`, `verify_delivery.ps1`
- `reports/delivery_report.md`

## Architecture Changes

- Experiments run through Hydra with per-run resolved configs, command logs, stdout, stderr, and JSON metadata.
- Hydra runs capture dependency/git environment manifests, SHA-256 output manifests, and run-local artifact copies.
- Repository audit enforces complete CLI-argument coverage for every Hydra experiment configuration.
- Phase 1 event data now has a versioned schema, deterministic OCR corruption expansion, and grouped label-aware train/validation/test splits.
- Phase 2 event-normalization benchmarking compares deterministic parser, zero-shot, few-shot, and candidate-ranking approaches on the same grouped split.
- A constrained text-model decision baseline evaluates prompt-to-action behavior against historical poker actions.
- Training and evaluation use grouped holdout metadata to reduce leakage risk.
- Missing-card requests use an explicit fallback path instead of relying on dead card-strength features.
- The API exposes deterministic health metadata from the packaged model artifact.
- Delivery verification checks source syntax, model loading, inference contract, health contract, reports, hygiene, and ZIP contents.
- Docker and Compose use the same port and bundled model path as the local service scripts.

## Hydra Configuration Structure

```text
configs/
|-- experiment.yaml
|-- dataset/
|-- model/
|-- training/
|-- evaluation/
|-- inference/
|-- logging/
|-- prompts/
`-- experiments/
```

Configured experiment files:

- `audit_dataset.yaml`
- `build_event_schema_dataset.yaml`
- `evaluate_policy.yaml`
- `llm_event_benchmark.yaml`
- `llm_event_extraction_smoke.yaml`
- `llm_event_gold_eval.yaml`
- `llm_transformer_gold_eval.yaml`
- `llm_decision_baseline.yaml`
- `phase2_event_benchmark.yaml`
- `build_dataset.yaml`
- `repo_hygiene.yaml`
- `production_gate.yaml`
- `repo_audit.yaml`
- `research_compare_tabular.yaml`
- `train_routed_bundle_smoke.yaml`
- `train_single_hgb.yaml`
- `verify_delivery.yaml`

## Model Metrics

- Accuracy: `0.6798`
- Majority baseline accuracy: `0.7029`
- Lift vs majority: `-0.0231`
- Balanced accuracy: `0.4415`
- Macro F1: `0.4135`
- Weighted F1: `0.6636`
- Calibration ECE@10: `0.0762`

## LLM/Text Event Extraction Results

- Phase 1 schema version: `event_schema_v1`
- Phase 1 parent examples: `24`
- Phase 1 expanded examples: `120`
- Phase 1 grouped split rows: `train=75`, `valid=20`, `test=25`
- Phase 1 validation status: `PASS`
- Weak-label benchmark records: `1000`
- Baseline event accuracy: `0.4150`
- Baseline macro F1: `0.3284`
- Structured extractor event accuracy: `1.0000`
- Structured extractor macro F1: `1.0000`
- Gold examples: `24`
- Strict schema event accuracy: `1.0000`
- Strict schema macro F1: `1.0000`
- Strict schema card exact match: `0.8000`
- Real instruction model: `HuggingFaceTB/SmolLM2-135M-Instruct`
- Strict zero-shot accuracy / macro F1: `0.2917 / 0.1129`
- Few-shot accuracy / macro F1: `0.3750 / 0.1364`
- Few-shot accuracy improvement: `+0.0833`
- Candidate ranker accuracy / macro F1: `0.3750 / 0.1364`
- Contextually calibrated ranker accuracy / macro F1: `0.3750 / 0.1406`
- Calibration macro-F1 improvement over raw candidate ranking: `+0.0043`
- Schema-routed LLM hybrid accuracy / macro F1: `1.0000 / 1.0000`
- Hybrid router coverage: `0.9167`
- Real LLM fallback count / rate / accuracy: `2 / 0.0833 / 1.0000`

## Phase 2 Event-Normalization Benchmark

- Evaluated examples: `25`
- Split: `test`
- Default backend: `heuristic`
- Best method: `deterministic_parser`
- Best exact-event accuracy: `1.0000`
- Best macro F1: `1.0000`
- Schema validity rate: `1.0000`
- Zero-shot exact-event accuracy / macro F1: `0.9600 / 0.7414`
- Few-shot-5 exact-event accuracy / macro F1: `1.0000 / 1.0000`
- Few-shot-10 exact-event accuracy / macro F1: `1.0000 / 1.0000`
- Candidate-ranker exact-event accuracy / macro F1: `1.0000 / 1.0000`
- Report: `reports/phase2_event_benchmark_report.md`

## LLM Decision Baseline Results

- Evaluated examples: `250`
- Provider: `heuristic_text`
- Mode: `candidate_ranker`
- Accuracy: `0.1440`
- Macro F1: `0.1007`
- Weighted F1: `0.1357`
- Cross entropy: `2.0541`
- Invalid output rate: `0.0000`
- Mean latency: `0.10 ms`
- Report: `reports/llm_decision_agent_report.md`

This baseline is intentionally tracked separately from the supervised policy model. It provides a reproducible Phase 1 comparison point and confirms that direct text-model decisioning is currently weaker than the supervised policy path.

## Remaining Risks

- `blocker`: Hole-card coverage is too low for card-strength modeling. High. The model will underuse the most important poker signal.
- `high`: Target distribution is dominated by one action class. High. Accuracy can improve while minority action recall remains poor.
- `high`: Critical feature `strength_proxy` is zero for most audited examples. Medium to high depending on street/action mix.
- `high`: The hybrid LLM result is measured on only 24 reviewed examples and depends on stable event names. Expand the fixture with corrupted and ambiguous event-name cases before production approval.

## Acceptance Position

The software package, experiment workflow, LLM/text extraction evidence, reports, and API contract are ready for engineering handoff. The decision model should remain research-stage until dataset blockers are resolved and the production gate passes without override.
