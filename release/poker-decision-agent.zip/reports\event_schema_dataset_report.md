# Phase 1 Event Schema Dataset

## Summary

- Status: `PASS`
- Schema version: `event_schema_v1`
- Parent examples: `24`
- Expanded examples: `120`
- Groups: `24`

## Label Counts

| Label | Count |
| --- | ---: |
| card_update | 25 |
| player_action | 45 |
| stack_update | 15 |
| unmatched | 35 |

## Split Counts

| Split | Rows |
| --- | ---: |
| test | 25 |
| train | 75 |
| valid | 20 |

## Noise Counts

| Noise | Count |
| --- | ---: |
| amount_text_noise | 24 |
| card_format_noise | 24 |
| clean | 24 |
| event_name_noise | 24 |
| value_ocr_noise | 24 |

## Validation

All rows are validated against the internal event schema before writing the dataset.
