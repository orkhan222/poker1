# Gold Event Extraction Evaluation

## Objective

Evaluate prompt-policy variants for converting OCR/dealer records into structured poker events.

## Dataset

Gold fixture: `C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2\evaluation\event_extraction_gold.jsonl`
Examples: `24`

## Prompt Variants

- minimal_action_only: `C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2\configs\prompts\event_extraction_minimal.txt`
- permissive_prompt_rules: `C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2\configs\prompts\event_extraction_permissive.txt`
- strict_schema_rules: `C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2\configs\prompts\event_extraction_strict.txt`

## Metrics

- Event type accuracy and macro F1
- Decision-action exact match
- Card exact match
- Amount exact match
- Invalid action count

## Results

| System | Event accuracy | Macro F1 | Action exact | Card exact | Amount exact |
| --- | ---: | ---: | ---: | ---: | ---: |
| minimal_action_only | 0.6667 | 0.4091 | 1.0000 | 0.0000 | 0.6667 |
| permissive_prompt_rules | 0.8333 | 0.8545 | 1.0000 | 0.8000 | 1.0000 |
| strict_schema_rules | 1.0000 | 1.0000 | 1.0000 | 0.8000 | 1.0000 |

## Interpretation

The strict schema policy performs best because it separates decision actions from blinds, antes, winnings, seat joins, stack updates, and card-recognition records. The permissive variant preserves cards and stacks but over-classifies non-decision action rows. The minimal variant is precise for visible decision actions but cannot recover card or stack events.

## Limitations

The fixture is intentionally small and should be expanded with manually reviewed production logs before using extracted events as training labels.
