# Phase 2 Event-Normalization Baseline Benchmark

## Objective

Compare deterministic parsing, zero-shot extraction, few-shot extraction, and candidate ranking on the same grouped OCR/dealer-log evaluation split.

## Dataset

- Dataset: `evaluation\event_extraction_phase1.jsonl`
- Split: `test`
- Examples: `25`
- Backend: `heuristic`
- Models: `heuristic_text`

## Results

| method | model | accuracy | macro_f1 | precision_macro | recall_macro | schema_validity_rate | event_type_exact_match | action_exact_match | amount_exact_match | average_latency_ms | peak_memory_mb | unmatched_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| deterministic_parser | - | 0.6800 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 0.2000 | 17.0766 | 0.0670 | 0.0000 |
| few_shot_5 | heuristic_text | 0.6800 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 0.2000 | 15.1990 | 0.0504 | 0.0000 |
| few_shot_10 | heuristic_text | 0.6800 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 0.2000 | 15.3676 | 0.0525 | 0.0000 |
| candidate_ranker | heuristic_text | 0.6800 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 0.2000 | 16.6678 | 0.0881 | 0.0000 |
| zero_shot | heuristic_text | 0.6400 | 0.5931 | 0.6000 | 0.5867 | 1.0000 | 0.9600 | 0.9333 | 0.2000 | 16.2194 | 0.0499 | 0.0400 |

## Best System

`deterministic_parser` with model `-` reached macro F1 `0.6000` and exact-event accuracy `0.6800`.

## Notes

The default backend is deterministic and intended for reproducible local delivery checks. Use `--backend transformers` with the configured model IDs to run the same benchmark against Qwen or SmolLM models when the model weights are available locally or can be downloaded.
