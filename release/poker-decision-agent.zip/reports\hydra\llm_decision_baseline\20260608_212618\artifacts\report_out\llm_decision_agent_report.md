# Text-Model Poker Decision Baseline

## Objective

Evaluate a constrained text-model decision pipeline on historical poker actions. The model receives structured game state and returns one discrete action.

## Configuration

- Provider: `heuristic_text`
- Mode: `candidate_ranker`
- Model ID: `local_scoring_policy`
- Examples: `250`
- Seed: `42`

## Metrics

| Metric | Value |
| --- | ---: |
| Accuracy | 0.1440 |
| Macro F1 | 0.1007 |
| Weighted F1 | 0.1357 |
| Balanced accuracy | 0.3417 |
| Cross entropy | 2.0541 |
| Brier loss | 0.1862 |
| Majority baseline accuracy | 0.7120 |
| Lift vs majority | -0.5680 |
| Invalid output rate | 0.0000 |

## Latency

- Mean: `0.11 ms`
- P50: `0.10 ms`
- P95: `0.14 ms`

## Notes

This baseline is intended for comparison against the supervised policy model. The recommended production path remains a schema-routed extractor for noisy logs and a separately validated policy model for poker decisions.
