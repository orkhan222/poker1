# Phase 2 Event-Normalization Baseline Benchmark

## Objective

Compare deterministic parsing, zero-shot extraction, few-shot extraction, and candidate ranking on the same grouped OCR/dealer-log evaluation split.

## Dataset

- Dataset: `evaluation\event_extraction_phase1.jsonl`
- Split: `test`
- Examples: `25`
- Backend: `heuristic`
- Models: `heuristic_text`

## Results

| method | model | accuracy | macro_f1 | precision_macro | recall_macro | schema_validity_rate | event_type_exact_match | action_exact_match | amount_exact_match | average_latency_ms | peak_memory_mb | unmatched_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| deterministic_parser | - | 1.0000 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 20.8400 | 0.0679 | 0.0000 |
| few_shot_5 | heuristic_text | 1.0000 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 17.1815 | 0.0505 | 0.0000 |
| few_shot_10 | heuristic_text | 1.0000 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 18.7979 | 0.0526 | 0.0000 |
| candidate_ranker | heuristic_text | 1.0000 | 0.6000 | 0.6000 | 0.6000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 22.5474 | 0.0839 | 0.0000 |
| zero_shot | heuristic_text | 0.9600 | 0.5931 | 0.6000 | 0.5867 | 1.0000 | 0.9600 | 0.9333 | 1.0000 | 20.4262 | 0.0500 | 0.0400 |

## Best System

`deterministic_parser` with model `-` reached macro F1 `0.6000` and exact-event accuracy `1.0000`.

## Notes

The default backend is deterministic and intended for reproducible local delivery checks. Use `--backend transformers` with the configured model IDs to run the same benchmark against Qwen or SmolLM models when the model weights are available locally or can be downloaded.
