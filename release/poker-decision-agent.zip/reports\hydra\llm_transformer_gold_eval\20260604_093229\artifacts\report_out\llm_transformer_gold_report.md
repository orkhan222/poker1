# Local Instruction Model Event Extraction Evaluation

## Objective

Measure whether a compact local instruction model can convert OCR/dealer records into schema-valid poker events, and compare unconstrained generation with candidate-likelihood ranking.

## Dataset

Gold fixture: `evaluation\event_extraction_gold.jsonl`
Model: `HuggingFaceTB/SmolLM2-135M-Instruct`
Examples: `24`
Label counts: `{"card_update": 5, "player_action": 9, "stack_update": 3, "unmatched": 7}`
Seed: `42`

## Results

| System | Event accuracy | Macro F1 | Action exact | Card exact | Amount exact | Structured output | Seconds/example |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| smol_strict_zero_shot | 0.2917 | 0.1129 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | 5.0951 |
| smol_few_shot | 0.3750 | 0.1364 | 1.0000 | 0.0000 | 0.5556 | 1.0000 | 4.6397 |
| smol_candidate_ranker | 0.3750 | 0.1364 | 1.0000 | 0.0000 | 1.0000 | 1.0000 | 3.2715 |
| smol_calibrated_candidate_ranker | 0.3750 | 0.1406 | 1.0000 | 0.0000 | 1.0000 | 1.0000 | 3.4231 |

## Method

The same reviewed fixture is evaluated with strict zero-shot generation, few-shot generation, constrained candidate ranking, and contextually calibrated candidate ranking. Generation is deterministic (`do_sample=False`). Candidate ranking compares normalized conditional losses for the allowed event labels. Contextual calibration subtracts each label's loss on a neutral record before selection. The selected label is then mapped into the output schema.

## Findings

Best macro F1: `smol_calibrated_candidate_ranker` at `0.1406`.
- `smol_strict_zero_shot` predicted counts: `{"unmatched": 24}`
- `smol_few_shot` predicted counts: `{"player_action": 24}`
- `smol_candidate_ranker` predicted counts: `{"player_action": 24}`
- `smol_calibrated_candidate_ranker` predicted counts: `{"card_update": 1, "player_action": 23}`

Free-form generation is sensitive to prompt priors and can collapse to one class. Candidate ranking removes invalid event labels and exposes per-label losses, but it does not replace the need for a stronger model or a larger reviewed evaluation set.

## Limitations

This is a small CPU-oriented model and a small reviewed fixture. The candidate-ranked workflow uses deterministic schema mapping for fields after the model selects the event type. Results measure structured extraction behavior, not general poker reasoning quality.
