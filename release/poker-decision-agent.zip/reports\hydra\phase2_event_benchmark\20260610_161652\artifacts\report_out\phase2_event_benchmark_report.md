# Phase 2 Event-Normalization Baseline Benchmark

## Objective

Compare deterministic parsing, zero-shot extraction, few-shot extraction, and candidate ranking on the same grouped OCR/dealer-log evaluation split.

## Dataset

- Dataset: `evaluation\event_extraction_phase1.jsonl`
- Split: `test`
- Examples: `25`
- Backend: `heuristic`
- Models: `heuristic_text`

## Results

| method | model | accuracy | macro_f1 | precision_macro | recall_macro | schema_validity_rate | event_type_exact_match | action_exact_match | amount_exact_match | average_latency_ms | peak_memory_mb | unmatched_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| deterministic_parser | - | 0.4800 | 0.5278 | 0.5286 | 0.5400 | 1.0000 | 0.7200 | 0.9000 | 0.0000 | 17.7873 | 0.0647 | 0.0800 |
| zero_shot | heuristic_text | 0.4800 | 0.5278 | 0.5286 | 0.5400 | 1.0000 | 0.7200 | 0.9000 | 0.0000 | 15.3765 | 0.0498 | 0.0800 |
| few_shot_5 | heuristic_text | 0.4800 | 0.5278 | 0.5286 | 0.5400 | 1.0000 | 0.7200 | 0.9000 | 0.0000 | 15.2763 | 0.0505 | 0.0800 |
| few_shot_10 | heuristic_text | 0.4800 | 0.5278 | 0.5286 | 0.5400 | 1.0000 | 0.7200 | 0.9000 | 0.0000 | 16.3791 | 0.0526 | 0.0800 |
| candidate_ranker | heuristic_text | 0.4800 | 0.5096 | 0.4952 | 0.5400 | 1.0000 | 0.7200 | 0.9000 | 0.0000 | 16.3604 | 0.0883 | 0.0400 |

## Best System

`deterministic_parser` with model `-` reached macro F1 `0.5278` and exact-event accuracy `0.4800`.

## Notes

The default backend is deterministic and intended for reproducible local delivery checks. Use `--backend transformers` with the configured model IDs to run the same benchmark against Qwen or SmolLM models when the model weights are available locally or can be downloaded.
